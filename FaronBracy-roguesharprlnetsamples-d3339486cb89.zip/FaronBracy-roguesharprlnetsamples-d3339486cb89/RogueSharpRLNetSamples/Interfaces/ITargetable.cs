﻿using RogueSharp;

namespace RogueSharpRLNetSamples.Interfaces
{
   public interface ITargetable
   {
      void SelectTarget( Point target );
   }
}
